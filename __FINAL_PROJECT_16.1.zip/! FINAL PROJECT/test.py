from button import Button
import pygame
from itemList import *
import Mob
import time

pygame.init()
screen = pygame.display.set_mode((1280, 720))
width = screen.get_width()
height = screen.get_height()
running = True

screen.blit(pygame.image.load('inv_bg.png'), (0, 0))
pygame.display.update()


while running:
    if pygame.mouse.get_pressed(3)[2]:
        print('clicked')
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.time.Clock().tick(30)
